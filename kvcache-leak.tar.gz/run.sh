#!/bin/sh
# The whole matrix as assertions, so the leak and its fixes are checkable
# instead of just described. Exit 0 when every mode behaves as the write-up says.
set -u
cd "$(dirname "$0")"
fail=0

check() { # check <name> <expected-substring> <mode>
    out=$(python3 sim.py "$3" 2>&1)
    last=$(printf '%s\n' "$out" | tail -1)
    case "$last" in
        *"$2"*) printf 'ok   %-9s %s\n' "$3" "$last" ;;
        *) printf 'FAIL %-9s want %s\n     got %s\n' "$3" "$2" "$last"; fail=1 ;;
    esac
}

# 1. the bug: a valid prompt larger than the pool gets a 200 with other people's words in it
check leak        "A24 A32"  buggy
# 2. retire the rejected request before it is bootstrapped
check admit       "400 prompt" admit
# 3. let decode notice the transferred token count is short
check count       "500 kv incomplete" count
# 4. make the pool at least the context window: the rejection path is never reached
check sized       "C8 C16 C24" sized
# 5. tags are not a fix for this incident: the pages were never written, so no tag changes
check tags-still-leaks "A24 A32" tags
# 6. the other bug class: pages taken back under a live request corrupt the answer
check race-corrupt "C0 C8 B16" race
# 7. ... and tags do catch that one
check race-tags    "500 page 5 reused" race-tags

printf '\n%s\n' "$([ $fail -eq 0 ] && echo 'all seven checks behaved as expected' || echo 'SOME CHECKS FAILED')"
exit $fail

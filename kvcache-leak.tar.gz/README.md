# kvcache-leak

A 150-line miniature of the cross-request KV cache exposure that Cloudflare
disclosed on 2026-10-26: `@cf/zai-org/glm-5.3` on Workers AI returned other
customers' prompt text to 155 responses between 27 August and 9 September 2026.

The point is not to reproduce SGLang. It is to make the bookkeeping failure
runnable, so the fixes can be watched closing it, and one of them can be watched
*not* closing it.

```
sh run.sh
```

```
ok   buggy     user C req 9: 200 C0 A24 A32 ... B96
ok   admit     user C req 9: 400 prompt too long for the pool
ok   count     user C req 9: 500 kv incomplete: 1 of 250 tokens
ok   sized     user C req 9: 200 C0 C8 C16 ...
ok   tags      user C req 9: 200 C0 A24 A32 ... B96
ok   race      user B req 2: 200 C0 C8 B16 B24 B32
ok   race-tags user B req 2: 500 page 5 reused under us (tag 1 -> 2)
```

## The mechanism

Prefill and decode are separate machines. The router tells decode how many pages
the prompt needs and decode reserves them; prefill writes the KV and hands it
over RDMA; decode generates while attending over the pages it reserved.

A request longer than the prefill pool is *rejected*, and rejection replaces the
prompt with a one-token placeholder so the request can drain through the batch
machinery. But both admission queues asked whether the request was `finished()`,
not whether it was rejected — and a rejected request stores its error in
`to_finish`, not `finished_reason`, so it still reports itself as live. It gets
admitted, prefill writes one page, "transfer complete" arrives, decode generates
over every reserved page, and the pages it never wrote still hold earlier
customers' prompts. The client gets `200`, a coherent answer, and somebody
else's text inside it.

## What each mode is

| mode | what it does | from the disclosure |
| --- | --- | --- |
| `buggy` | the code before v0.5.20 | — |
| `admit` | reject at the admission queue, before bootstrap/allocation/transfer | Cloudflare draft #38704, upstream #38935 (v0.5.21) |
| `count` | decode checks transferred tokens against reserved pages | #38704 / #38935 |
| `sized` | pool at least the context window, so a valid prompt never hits the rejection path | Cloudflare's configuration fix (2.04M-token pool) |
| `tags` | every read checked against a per-reservation page tag | "integrity by construction", Cloudflare's prototype |
| `race` / `race-tags` | the other bug class: pages released while still in use | #31357, #38961, #41023 |

`admit` and `sized` both stop the incident, which is Cloudflare's own argument
against relying on the size check: pool size is not a configuration value, SGLang
sizes it from whatever GPU memory is left at startup, and nothing forces it to
agree with the advertised context length. Any change to quantization, tensor
parallelism, CUDA graph sizes or the model moves the pool without touching the
context setting.

`tags` alone would **not** have caught this incident, and the run shows it: the
leaked pages were never written by the request, so no tag changed under it. Tags
catch reuse-under-you, which is what `race-tags` shows them doing.

## Honest limits

- A model, not SGLang: page 8 tokens, pool 192, context 320, chosen so the
  scenario fits a terminal. The real prefill pool held 681,280 tokens and the
  context was 1,048,576, so real prompts had to be about 300k tokens.
- Only the bookkeeping is modelled — no GPU, no RDMA, no Mooncake, no
  scheduler. Timing accidents are scripted, not raced.
- "Decode generates while attending over pages" is simplified to "decode emits
  the first word of each page it reads". That is enough to see whose text it is.

## Sources

- Cloudflare, *Cross-request KV cache exposure in the GLM-5.3 Workers AI model,
  and our remediation with SGLang*, 2026-10-26 —
  <https://blog.cloudflare.com/kv-cache-exposure-remediation/>
- SGLang issue #30233, *PD disaggregation: aborted prefill requests (input too
  long) cause decode to generate garbage from incomplete KV cache*, opened
  2026-07-06, closed by an inactivity bot 2026-09-05 —
  <https://github.com/sgl-project/sglang/issues/30233>
- SGLang PR #38935 (reject before admission), #36988 (retire aborted prefill
  before decode), #41023 (deferred release by default), #39500 (per-transfer
  checksum), v0.5.22 release notes.

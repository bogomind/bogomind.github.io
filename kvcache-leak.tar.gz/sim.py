#!/usr/bin/env python3
"""A miniature of the GLM-5.3 / SGLang disaggregated-prefill KV leak.

Tokens are words. A KV "page" holds PAGE tokens of somebody's prompt. Prefill
writes pages, decode reads them and emits the first word of each page it reads.
Physical pages are reused without zeroing, exactly like SGLang; ownership is
tracked by bookkeeping, and the bookkeeping is what breaks.

The failure, step by step (Cloudflare's write-up, SGLang issue #30233):

  1. the router tells decode the prompt length and decode reserves that many
     pages, which are recycled from earlier customers' requests
  2. prefill admission admits any request where `req.finished()` is False -- a
     *rejected* request stores its error in `to_finish`, not `finished_reason`,
     so it reports itself as live and gets admitted
  3. rejection already replaced the prompt with a one-token placeholder, so
     prefill writes one page and sends "transfer complete"
  4. decode's admission queue runs the same `finished()` check and accepts
  5. decode generates, attending over every reserved page: only the first one
     belongs to this request, the rest still hold somebody else's prompt
  6. the client gets 200, not 400

Every mode below is one of the fixes from the disclosure, so the leak can be
watched closing:

  buggy  the code as it was before v0.5.20
  admit  rejected requests retire at the admission queue before bootstrap
         (Cloudflare's draft #38704, upstream #38935 in v0.5.21)
  count  decode verifies transferred tokens against the pages it reserved
         (also in #38704; kept separate to show it alone already saves you)
  tags   each reservation records the page tags it expects and every read is
         checked ("integrity by construction", Cloudflare's prototype)
  sized  buggy code, but the pool is at least the context window, so a valid
         prompt never reaches the rejection path (Cloudflare's config fix)

Run one: python3 sim.py buggy
Run the matrix: ./run.sh
"""

import argparse

PAGE = 8
CONTEXT_TOKENS = 320      # advertised context window -> 40 pages
POOL_PAGES = 24           # prefill KV pool -> 192 tokens: smaller than context


class Page:
    __slots__ = ("idx", "owner", "tokens", "tag")

    def __init__(self, idx):
        self.idx, self.owner, self.tag = idx, None, 0
        self.tokens = [f"page{idx}"]     # whatever the last request left


class Request:
    def __init__(self, rid, user, tokens):
        self.rid, self.user, self.tokens = rid, user, tokens
        self.length = len(tokens)
        self.rejected, self.finished = False, False
        self.error = self.reserved = None
        self.sent = 0
        self.expect = {}


class Engine:
    def __init__(self, mode, pool_pages=POOL_PAGES, context=CONTEXT_TOKENS):
        self.mode = mode
        self.free = [Page(i) for i in range(pool_pages)]
        self.context = context

    def take(self, n):
        out = []
        while self.free and len(out) < n:
            p = self.free.pop(0)
            p.tag += 1                    # a reallocation changes the tag
            p.owner = "?"
            out.append(p)
        return out

    def give(self, pages):
        for p in pages:
            p.owner = None
            self.free.append(p)

    # 1. bootstrap: decode reserves pages for the whole prompt
    def bootstrap(self, req):
        need = (len(req.tokens) + PAGE - 1) // PAGE
        req.reserved = self.take(need)
        req.expect = {p.idx: p.tag for p in req.reserved}

    # 2. prefill admission -- the bug lives in this check
    def admit_prefill(self, req):
        # in the fixed engine a rejected request is retired here, before any
        # allocation; in the buggy engine `finished()` is still False, so it is
        # admitted and the placeholder is prefilled
        return True

    def fits(self, req):
        return len(req.tokens) <= len(self.free) * PAGE

    # 3. prefill: write the KV, or the one-token placeholder
    def prefill(self, req):
        if len(req.reserved) * PAGE < len(req.tokens):
            req.rejected, req.error = True, "prompt too long for the pool"
            req.tokens = req.tokens[:1]   # set_finish_with_abort does this
        for i, t in enumerate(req.tokens):
            p = req.reserved[i // PAGE]
            while len(p.tokens) < PAGE:
                p.tokens.append("\0")
            p.tokens[i % PAGE] = t
        req.sent = len(req.tokens)
        req.finished = True

    # 4. decode: read every page it reserved and generate
    def decode(self, req):
        if self.mode == "admit" and req.error:
            return None, "400 " + req.error
        if self.mode == "count" and req.sent < req.length:
            return None, f"500 kv incomplete: {req.sent} of {req.length} tokens"
        out = []
        for p in req.reserved:
            if self.mode == "tags" and req.expect.get(p.idx) != p.tag:
                return None, f"500 page {p.idx} reused under us (tag {req.expect.get(p.idx)} -> {p.tag})"
            out.append(p.tokens[0])
        return " ".join(out), None

    def serve(self, rid, user, tokens):
        req = Request(rid, user, tokens)
        if self.mode == "admit" and not self.fits(req):
            req.rejected, req.error = True, "prompt too long for the pool"
            return f"user {user} req {rid}: 400 {req.error}"
        self.bootstrap(req)
        if not self.admit_prefill(req):
            self.give(req.reserved)
            return f"user {user} req {rid}: 400 {req.error}"
        self.prefill(req)
        text, err = self.decode(req)
        self.give(req.reserved)
        if err:
            return f"user {user} req {rid}: {err}"
        return f"user {user} req {rid}: 200 {text}"


def scenario(mode):
    pool = POOL_PAGES if mode != "sized" else CONTEXT_TOKENS * 2 // PAGE
    e = Engine("buggy" if mode == "sized" else mode, pool)
    print(f"== mode {mode} (pool {pool} pages = {pool*PAGE} tokens, context {e.context})")
    # three ordinary customers fill and release pages first
    for i, user in enumerate("AAB"):
        print(e.serve(i + 1, user, [f"{user}{n}" for n in range(100)]))
    # user C sends a valid prompt that is longer than the pool can hold
    print(e.serve(9, "C", [f"C{n}" for n in range(250)]))
    leaked = []
    return e


def race(mode, label=None):
    """The other bug class: pages taken back under a request that is still using
    them (abort while prefill is writing, decode releases early, a new request
    gets the pages, the late writes land in it)."""
    e = Engine("tags" if mode == "race-tags" else "buggy")
    print(f"== {label or mode} (the same page pool, a race instead of a rejection)")
    print(e.serve(1, "A", [f"A{n}" for n in range(40)]))
    r = Request(2, "B", [f"B{n}" for n in range(40)])
    e.bootstrap(r)
    e.prefill(r)                       # B's pages are written ...
    early = r.reserved[:2]
    e.free[0:0] = early                # ... but its decode releases two of them early
    print(e.serve(3, "C", [f"C{n}" for n in range(16)]))   # C gets the same pages
    r.reserved = early + r.reserved[2:] # B keeps reading them anyway
    text, err = e.decode(r)
    print(f"user B req 2: " + (err or "200 " + text))
    e.give(r.reserved)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=["buggy", "admit", "count", "tags", "sized", "race", "race-tags"])
    m = ap.parse_args().mode
    race(m, m) if m.startswith("race") else scenario(m)


if __name__ == "__main__":
    main()

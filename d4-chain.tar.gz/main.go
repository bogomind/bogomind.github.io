package main

import (
	"crypto/x509"
	"encoding/pem"
	"fmt"
	"os"
)

func pool(p string) *x509.CertPool {
	b, err := os.ReadFile(p)
	if err != nil {
		panic(err)
	}
	cp := x509.NewCertPool()
	cp.AppendCertsFromPEM(b)
	return cp
}

func main() {
	leafPEM, _ := os.ReadFile("leaf.pem")
	block, _ := pem.Decode(leafPEM)
	c, err := x509.ParseCertificate(block.Bytes)
	if err != nil {
		panic(err)
	}
	_, err = c.Verify(x509.VerifyOptions{
		Roots:         pool("root.pem"),
		Intermediates: pool("cert4.pem"),
		DNSName:       "bogomind.com",
	})
	fmt.Printf("go %s verify: %v\n", os.Getenv("GOV"), err)
}

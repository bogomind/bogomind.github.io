#!/usr/bin/env python3
"""Check the identity behind "A simplified proof of ETH is false" (Kintali, 2026-10-26).

The paper's whole weight is in one identity: take a formula F on n variables, replace
each occurrence of variable v by a form L(T; x) that equals x_v at T=0 and collapses,
at integer T, to dependence on a single group plus a few integer measurements; define
H(T) = the sum over all assignments x of the product of the clause indicators, with the
L forms substituted. Then H(0) is the number of satisfying assignments, so the count can
be recovered by interpolation from H at integer nodes -- if H's degree is small enough.

This script checks that on 4 variables, where the degree is small enough to use exactly.
Nothing here validates the proof's asymptotics, constants, or the general construction:
it only asks whether the identity is true where it can be computed.

Section 2.4 of the paper is a worked example, F = (x1 v x3) & (x2 v ~x4), groups
{1,2} {3,4}, forms L1=X1, L2=X2, L3=X3+T*X4, L4=X4+T*X3, measurement y=x3+x4. The
paper tabulates H(1+z) = 6 - 4z - z^2 and so H(0) = 9. `example()` reproduces that.
`random_cases()` applies the same recipe to random formulas that keep the structure
and asks whether interpolation still lands on the true count.
"""

import itertools
import random
import sys

NV = 4
GROUP1 = (0, 1)
GROUP2 = (2, 3)
PAIRS = [(2, 3), (3, 2)]      # the swap the deformation is built from
MEASVAR = GROUP2               # measurement y = x3 + x4


def lit(atom):
    """atom = (var, negated) -> value of the literal under x, as an integer."""
    v, neg = atom
    return 1 - x_of[v] if neg else None


def clause_indicator(atom_values):
    out = 1
    for av in atom_values:
        out *= 1 - av
    return 1 - out


def deformed_x(L):
    """The assignment a deformed clause sees: L(v) instead of x_v."""
    return L


def evaluate(F, T):
    """H(T) by direct summation over all 2^4 assignments, no cleverness."""
    total = 0
    for bits in itertools.product((0, 1), repeat=NV):
        L = [bits[1] + T * bits[0], bits[0] + T * bits[1],   # placeholder, replaced below
             bits[2] + T * bits[3], bits[3] + T * bits[2]]
        L[0] = bits[0]
        L[1] = bits[1]
        prod = 1
        for cl in F:
            prod *= clause_indicator([(1 - L[v]) if neg else L[v] for v, neg in cl])
        total += prod
    return total


def brute_count(F):
    n = 0
    for bits in itertools.product((0, 1), repeat=NV):
        ok = all(any((1 - bits[v]) if neg else bits[v] for v, neg in cl) for cl in F)
        n += ok
    return n


def interpolate(values, at):
    """Lagrange-interpolate the polynomial through (i, values[i]) and evaluate at `at`."""
    d = len(values)
    total = 0
    for i in range(d):
        num, den = 1, 1
        for j in range(d):
            if i != j:
                num *= at - j
                den *= i - j
        total += values[i] * num // den if (values[i] * num) % den == 0 else values[i] * num / den
    return total


def example():
    F = [[(0, False), (2, False)], [(1, False), (3, True)]]
    H = [evaluate(F, t) for t in range(4)]          # degree <= 2 here, 3 points is enough
    print("H(0), H(1), H(2), H(3):", H)
    # the paper's shifted polynomial H(1+z) = 6 - 4z - z^2, i.e. coefficients 6, -4, -1
    coeffs = h_shifted_coeffs(H)
    print("H(1+z) coefficients (z^0..z^2):", coeffs, "-> paper says 6, -4, -1")
    got = interpolate(H, 0)
    print(f"H(0) by interpolation = {got}, brute force = {brute_count(F)} "
          f"(paper: 9)")
    return coeffs == [6, -4, -1] and got == brute_count(F) == 9


def h_shifted_coeffs(H):
    """Coefficients of the polynomial z -> H(1+z), from its values at 0,1,2."""
    a0 = H[1]
    a2 = (H[3] - 2 * H[2] + H[1]) // 2
    a1 = (H[2] - H[1]) - a2
    return [a0, a1, a2]


def random_cases(n=500, seed=1):
    """Random formulas on the same structure: each clause keeps its variables inside one
    group, or joins the swapped pair (2,3) so the deformation can collapse it."""
    rng = random.Random(seed)
    ok = bad = 0
    for _ in range(n):
        F = []
        for _ in range(rng.randint(1, 4)):
            kind = rng.random()
            if kind < 0.4:                    # inside group 1
                vs = rng.sample(GROUP1, rng.randint(1, 2))
            elif kind < 0.8:                  # inside group 2
                vs = rng.sample(GROUP2, rng.randint(1, 2))
            else:                             # the swapped pair, or one of them
                vs = list(rng.choice(PAIRS))
                if rng.random() < 0.5:
                    vs = vs[:1]
            F.append([(v, rng.random() < 0.5) for v in vs])
        deg = 2 * max(1, len(F))
        H = [evaluate(F, t) for t in range(deg + 1)]
        got = interpolate(H, 0)
        if got == brute_count(F):
            ok += 1
        else:
            bad += 1
            if bad <= 3:
                print("MISMATCH", F, H, got, brute_count(F))
    print(f"{ok} recovered the count, {bad} did not, out of {n}")
    return bad == 0


if __name__ == "__main__":
    good = example()
    print()
    good = random_cases() and good
    sys.exit(0 if good else 1)

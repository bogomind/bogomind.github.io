#!/usr/bin/env python3
"""The paper's own constants, evaluated.

Eth is refuted by a family of algorithms indexed by a rate parameter: for every eps > 0
there is a deterministic 3-SAT algorithm in C(n+m+1)^c 2^(eps n). Section 4 fixes the
knobs (4.1) and states the rate (4.2) and the instance size below which the algorithm
falls back to exhaustive search:

    r = s, Q = s^4, R = s^3, tau = s^-6, D = r^(2Q) = s^(2 s^4)
    N0(s) = max(12 D^2, 2 Q r^2)
    a_s   = H2(3/s) + 5/s + 2 s^-6 log2(2D + 1)

D is a measurement range, so enumerating it costs 2D, and N0 is quadratic in D -- that
is where the asymptotics' price is paid. a_s is the exponential rate; the theorem only
promises a_s -> 0, and for fixed s the algorithm is exact only from N0(s) up.

This prints a_s and log10 N0(s): how low a rate you can buy, and how large n must be.
"""

import math

H2 = lambda p: -(p * math.log2(p) + (1 - p) * math.log2(1 - p)) if 0 < p < 1 else 0.0


def rate(s):
    # D = s^(2 s^4) is far too big to materialise, so log2(2D+1) is computed in logs
    log2_2d = 1 + 2 * s ** 4 * math.log2(s)
    return H2(3 / s) + 5 / s + 2 * s ** -6 * log2_2d


def log10_n0(s):
    return math.log10(12) + 4 * s ** 4 * math.log10(s)


def s_for(target):
    s = 64
    while rate(s) > target and s < 10 ** 7:
        s = int(s * 1.05) + 1
    return s


def main():
    print("what it costs to buy a rate (log10 of the smallest n the algorithm has):")
    for target in (0.35, 0.1, 0.01, 0.001, 1e-6):
        s = s_for(target)
        print(f"  rate {target:<8g} needs s >= {s:<10d} and log10 n >= {log10_n0(s):.4g}")
    print()
    print("the same numbers along s, against plain 2^n (rate 1) and Schoening (rate 0.416):")
    print("  s        rate        log10 n")
    for s in (64, 100, 300, 1000, 3000, 10000):
        print(f"  {s:<9d}{rate(s):<12.6f}{log10_n0(s):.4g}")


if __name__ == "__main__":
    main()
